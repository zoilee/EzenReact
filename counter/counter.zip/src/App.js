import './App.css';
import Counter from './component/Counter';

function App() {
  return (
    <div className="App">
      <Counter/>
    </div>
  );
}

export default App;
